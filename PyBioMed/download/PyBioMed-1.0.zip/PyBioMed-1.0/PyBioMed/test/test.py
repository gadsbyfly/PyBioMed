# -*- coding: utf-8 -*-
"""
The script is used for testing.

Authors: Zhijiang Yao and Dongsheng Cao.

Date: 2016.06.14

Email: gadsby@163.com 
"""


from PyBioMed.test import test_PyBioMed  

test_PyBioMed.test_pybiomed()















