# -*- coding: utf-8 -*-
"""
Created on 下午6:41 2017
PyBioMed20171228 was developed by Jie Dong et al. of CBDD GROUP of CSU China.
This project is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
Based on a work at http://home.scbdd.com.
Permissions beyond the scope of this license may be available at http://home.scbdd.com/. If you have any questions, please feel free to contact us.
E-mail: biomed@csu.edu.cn

@File name: writeCSV
@author: Jie Dong
"""
