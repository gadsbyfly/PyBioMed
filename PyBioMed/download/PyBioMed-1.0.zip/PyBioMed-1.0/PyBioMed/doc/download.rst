--------
Download
--------

Python Package
~~~~~~~~~~~~~~

Github (latest development): https://github.com/gadsbyfly/PyBioMed/


Documentation
~~~~~~~~~~~~~
*PDF*

https://github.com/gadsbyfly/PyBioMed/tree/master/PyBioMed/download/PyBioMed%20Documentation.pdf

The introduction of descriptors
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*PDF*

Molecular descriptors introduction
++++++++++++++++++++++++++++++++++
https://github.com/gadsbyfly/PyBioMed/blob/master/doc/DescriptorIntroduction/PyBioMed%20Chem.pdf

Protein descriptors introduction
++++++++++++++++++++++++++++++++
https://github.com/gadsbyfly/PyBioMed/blob/master/doc/DescriptorIntroduction/PyBioMed%20Protein.pdf

DNA descriptors introduction
++++++++++++++++++++++++++++
https://github.com/gadsbyfly/PyBioMed/blob/master/doc/DescriptorIntroduction/PyBioMed%20DNA.pdf

Interaction descriptors introduction
++++++++++++++++++++++++++++++++++++
https://github.com/gadsbyfly/PyBioMed/blob/master/doc/DescriptorIntroduction/PyBioMed%20Interaction.pdf















